# Steam Idle Booster
### Open Script for Community

This project is in progress at the moment.
the script give to you **Hours** in a lot of games and in the Future creating something like **Card Dropping,** using **HTML Forms**.
I know that already exists a lot of scripts for idle.. But i wanna be different and create my own scripts.

## Let's Beggin

Install the NodeJs from https://nodejs.org/en/
Open your **CMD Prompt**

Use **npm** to install the necessary  modules:
 npm install steam-user
 npm install fs
 npm install readline-sync
 npm install request

## Let's Start the bot

Go to **app.json** and change the **username** and the **passowrd**, then you need to enter the game Codes from http://steamcommunity.com/app/730 -> **730** ==  CS:GO
Use **node idlebot.js** to start your bot 

That's it! your Bot is Making Hours... ;D

Note: There is a game idle limit to Boost your account. Max **30** Games.

Donations: https://steamcommunity.com/tradeoffer/new/?partner=172427377&token=m9yCqbtE
http://steamcommunity.com/id/witcherpt/
